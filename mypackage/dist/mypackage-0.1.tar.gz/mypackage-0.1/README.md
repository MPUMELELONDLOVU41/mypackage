# mypackage
example of my first published python package

# building this package locally
"python setup.py sdist"

## installing this package from GitHub
'pip install Git+https://github.com/MPUMELELONDLOVU41/mpumelelo.git'

## update this package from GitHub
'pip install --upgrade git+https://github.com/MPUMELELONDLOVU41/mpumelelo.git'
